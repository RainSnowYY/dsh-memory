@echo off
chcp 65001 >nul
title 导出对话记录
setlocal
set "JS=%~dp0read-sessions.js"
if not exist "%JS%" goto NOJS

set "NODE="
for /d %%d in ("%USERPROFILE%\.dsh\dsh-runtimes\*") do (
    if exist "%%d\dependencies\node\bin\node.exe" set "NODE=%%d\dependencies\node\bin\node.exe"
)
if defined NODE goto RUN
for /f "delims=" %%p in ('where node 2^>nul') do if not defined NODE set "NODE=%%p"
if defined NODE goto RUN
goto NONODE

:RUN
"%NODE%" "%JS%"
if errorlevel 1 goto FAIL
echo.
echo  导出完了。打开「对话记录」文件夹就能翻。
pause
exit /b 0

:NONODE
echo.
echo  没找到跑脚本用的 node（DSH 自带的那个也没找到）。
echo.
echo  两个办法：
echo    1. 先打开一次 DSH，关掉，再双击本文件
echo    2. 把 read-sessions.js 拖进 DSH 对话框，说「跑一下这个」
echo.
pause
exit /b 1

:NOJS
echo.
echo  少了 read-sessions.js —— 它应该和本文件在同一个文件夹里。
echo  重新解压一次压缩包，把这两个文件一起拷过来。
echo.
pause
exit /b 1

:FAIL
echo.
echo  导出时出错了。把上面那段报错截图发给我。
echo.
pause
exit /b 1