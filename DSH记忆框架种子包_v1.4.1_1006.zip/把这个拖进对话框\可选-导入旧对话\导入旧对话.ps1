﻿<#
  导入旧对话 · 格式归一化工具
  作用：把你以前导出的聊天记录，统一变成"人能读、DSH 也好读"的 .md
  它只做格式转换，不做理解 —— 理解交给你的 DSH。

  用法：双击同目录的「导入旧对话.bat」（推荐），或直接跑：
        powershell -ExecutionPolicy Bypass -File 导入旧对话.ps1 -Src "D:\我的旧聊天"
#>

param(
    [string]$Src,
    [string]$Out,
    [int]$RecentN = -1
)

$ErrorActionPreference = 'Stop'

function Say($m) { Write-Host $m }

if (-not $Src) {
    Say ''
    Say '  把【文件夹】或【单个文件】拖进这个窗口，然后按回车：'
    $Src = Read-Host '  路径'
}
if (-not $Src) { Say '  没给路径，退出。'; exit 1 }
$Src = $Src.Trim().Trim('"').Trim("'")

if (-not (Test-Path -LiteralPath $Src)) { Say "  [失败] 找不到：$Src"; exit 1 }

if (-not $Out) { $Out = Join-Path $PSScriptRoot '导入结果' }

if ($RecentN -lt 0) {
    Say ''
    Say '  只导最近几个对话？'
    Say '     直接回车 = 30 个（推荐：快，而且够用）'
    Say '     输入 0    = 全部（会话多的时候会很慢、很占地方）'
    $r = Read-Host '  数量'
    if (-not $r) { $RecentN = 30 }
    elseif ($r -match '^\d+$') { $RecentN = [int]$r }
    else { $RecentN = 30 }
}
if (-not (Test-Path -LiteralPath $Out)) { New-Item -ItemType Directory -Path $Out -Force | Out-Null }

# ---------- 收集文件 ----------
$item = Get-Item -LiteralPath $Src
$files = @()
if ($item.PSIsContainer) {
    $files = Get-ChildItem -LiteralPath $Src -Recurse -File |
             Where-Object { $_.Extension -in '.json','.jsonl','.txt','.md' -and $_.FullName -notlike "*$Out*" }
} else {
    $files = @($item)
}
if ($files.Count -eq 0) { Say '  [失败] 这里面没有 .json/.jsonl/.txt/.md 文件。'; exit 1 }

$MAXMSG = 400    # 每个对话最多保留多少条
$MAXCH  = 800    # 每条消息最多多少字符

# ---------- 抽取器 ----------
function Conv-Msg($role, $text) {
    if (-not $text) { return $null }
    $t = ("" + $text).Trim()
    if (-not $t) { return $null }
    if ($t.Length -gt $MAXCH) { $t = $t.Substring(0, $MAXCH) + ' …（后面截断）' }
    $who = switch ($role) {
        'user'      { '你' }
        'assistant' { 'AI' }
        'system'    { '系统' }
        default     { if ($role) { $role } else { '未知' } }
    }
    return "- **$who**：$t"
}

function Get-JsonLines($obj) {
    # ChatGPT 官方导出：{title, create_time, mapping:{id:{message:{author:{role},content:{parts},create_time}}}}
    $lines = New-Object System.Collections.Generic.List[object]
    if ($obj.mapping) {
        $msgs = @()
        foreach ($k in $obj.mapping.PSObject.Properties.Name) {
            $m = $obj.mapping.$k.message
            if (-not $m) { continue }
            $role = $null
            if ($m.author) { $role = $m.author.role }
            $parts = $null
            if ($m.content) { $parts = $m.content.parts }
            if (-not $parts) { continue }
            $txt = ($parts | Where-Object { $_ -is [string] }) -join "`n"
            if (-not $txt) { continue }
            $ts = 0
            if ($m.create_time) { $ts = [double]$m.create_time }
            $msgs += [pscustomobject]@{ ts = $ts; role = $role; text = $txt }
        }
        $msgs = $msgs | Sort-Object ts
        foreach ($m in $msgs) { $l = Conv-Msg $m.role $m.text; if ($l) { $lines.Add($l) } ; if ($lines.Count -ge $MAXMSG) { break } }
        return $lines
    }
    return $null
}

function Get-ArrayMessages($arr) {
    # 通用：[{role:'user', content:'...'}] 或 [{role, content:[{type:'text',text:'...'}]}]
    $lines = New-Object System.Collections.Generic.List[object]
    foreach ($m in $arr) {
        if (-not $m) { continue }
        $role = $m.role; if (-not $role) { $role = $m.author }
        $txt = $m.content
        if ($txt -is [array]) { $txt = ($txt | ForEach-Object { if ($_.text) { $_.text } elseif ($_ -is [string]) { $_ } }) -join "`n" }
        if ($txt -is [pscustomobject]) { $txt = $txt.text }
        $l = Conv-Msg $role $txt
        if ($l) { $lines.Add($l) }
        if ($lines.Count -ge $MAXMSG) { break }
    }
    return $lines
}

function Convert-OneFile($f) {
    $ext = $f.Extension.ToLower()
    $raw = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    if (-not $raw) { $raw = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue }
    if (-not $raw) { return $null }
    $bad = 0   # 认不出/解析失败的条目数（截断报告要用）

    $lines = $null
    $kind = '文本'

    if ($ext -eq '.json') {
        try {
            $obj = $raw | ConvertFrom-Json -ErrorAction Stop
            $list = @($obj)
            if ($list.Count -eq 1 -and $list[0].mapping) {
                $lines = Get-JsonLines $list[0]; $kind = 'ChatGPT 导出'
            } elseif ($obj -is [array]) {
                # 可能是 [{title, mapping}...] 多个对话
                $convs = @($obj | Where-Object { $_.mapping })
                $total = $convs.Count
                if ($RecentN -gt 0 -and $total -gt $RecentN) {
                    $convs = $convs |
                        Sort-Object -Property @{ Expression = { if ($_.create_time) { [double]$_.create_time } else { 0 } } } -Descending |
                        Select-Object -First $RecentN
                    Say ("      （共 {0} 个对话，只取最近 {1} 个）" -f $total, $RecentN)
                }
                $all = New-Object System.Collections.Generic.List[object]
                foreach ($c in $convs) {
                    if ($c.mapping) {
                        $all.Add("## 对话：" + $(if ($c.title) { $c.title } else { '（无标题）' }))
                        $sub = Get-JsonLines $c
                        if ($sub) { foreach ($s in $sub) { $all.Add($s) } }
                    }
                }
                if ($all.Count -gt 0) { $lines = $all; $kind = 'ChatGPT 导出（多会话）' }
                else { $lines = Get-ArrayMessages $obj; $kind = 'JSON 消息数组' }
            } else {
                $lines = Get-ArrayMessages @($obj); $kind = 'JSON 对象'
            }
        } catch {
            $lines = $null
        }
    }
    elseif ($ext -eq '.jsonl') {
        $lines = New-Object System.Collections.Generic.List[object]
        foreach ($ln in ($raw -split "`r?`n")) {
            if (-not $ln.Trim()) { continue }
            try { $o = $ln | ConvertFrom-Json -ErrorAction Stop } catch { $bad++; continue }
            $role = $o.role; if (-not $role -and $o.author) { $role = $o.author.role }
            $txt = $o.content
            if ($txt -is [pscustomobject] -and $txt.parts) { $txt = ($txt.parts | Where-Object { $_ -is [string] }) -join "`n" }
            $l = Conv-Msg $role $txt
            if ($l) { $lines.Add($l) }
            if ($lines.Count -ge $MAXMSG) { break }
        }
        $kind = 'JSONL'
    }
    else {
        # 纯文本 / Markdown：原样保留（分段）
        $lines = New-Object System.Collections.Generic.List[object]
        $count = 0
        foreach ($p in ($raw -split "`r?`n")) {
            if (-not $p.Trim()) { continue }
            $lines.Add($p)
            $count++
            if ($count -ge $MAXMSG) { $lines.Add('（后面截断）'); break }
        }
        $kind = '文本 / Markdown'
    }

    if (-not $lines -or $lines.Count -eq 0) { return $null }

    $safe = ($f.BaseName -replace '[\\/:*?"<>|]', '_')
    $dst = Join-Path $Out ($safe + '_整理.md')
    $n2 = 2
    while (Test-Path -LiteralPath $dst) {
        $dst = Join-Path $Out ($safe + '_整理_' + $n2 + '.md')
        $n2++
    }
    $kb = [math]::Round($f.Length / 1KB, 1)
    $truncated = ($lines.Count -ge $MAXMSG) -or ($raw -match '后面截断')
    $head = @(
        "# 旧对话整理：$($f.Name)",
        "",
        "- 来源文件：$($f.Name)（只留文件名，不写本机完整路径）",
        "- 识别成：**$kind**",
        "- 整理时间：$(Get-Date -Format 'yyyy-MM-dd HH:mm')",
        "- 原始大小：$kb KB（$($raw.Length) 字）",
        "- 提取条数：$($lines.Count)（上限 $MAXMSG 条／每条 $MAXCH 字）",
        "- 是否截断：$(if ($truncated) { '是 —— 后面还有内容没进来；想全要就一次少给几个文件' } else { '否' })",
        "- 认不出／跳过：$bad 条",
        "",
        "> ⚠️ 这是给 DSH 读的素材，**可能含隐私，也可能有过期的旧事**。",
        "> 读之前先自己扫一眼；写进记忆卡时只写【现在还成立】的。",
        "",
        "---",
        ""
    )
    $outLines = New-Object System.Collections.Generic.List[string]
    foreach ($h in $head) { $outLines.Add([string]$h) }
    foreach ($l in $lines) { $outLines.Add([string]$l) }
    Set-Content -LiteralPath $dst -Value $outLines.ToArray() -Encoding UTF8
    return [pscustomobject]@{ file = $f.Name; kind = $kind; count = $lines.Count; out = $dst; truncated = $truncated; bad = $bad }
}

# ---------- 跑 ----------
Say ''
Say '  ================================================'
Say '    导入旧对话 · 开始'
Say '  ================================================'
Say ''

$ok = 0; $skip = 0; $trunc = 0
foreach ($f in $files) {
    try {
        $r = Convert-OneFile $f
        if ($r) {
            $ok++
            if ($r.truncated) { $trunc++ }
            $mark = if ($r.truncated) { '  ⚠️ 有截断' } else { '' }
            Say ("  [OK]   {0}  →  {1} 条（{2}）{3}" -f $r.file, $r.count, $r.kind, $mark)
        } else {
            $skip++
            Say ("  [跳过] {0}  （没从中提出对话）" -f $f.Name)
        }
    } catch {
        $skip++
        Say ("  [跳过] {0}  （{1}）" -f $f.Name, $_.Exception.Message)
        Say ("        出错位置：" + $_.InvocationInfo.PositionMessage)
    }
}

Say ''
Say "  完成：成功 $ok 个（其中 $trunc 个有截断），跳过 $skip 个"
Say "  输出目录：$Out"
Say ''
Say '  ---- 接下来（两步）----'
Say '  1. 先自己扫一眼上面的结果，确认没有你不想让 AI 看到的东西'
Say '  2. 回去跟你的 DSH 说一句：'
Say '        「我导入了一些旧对话，你去读一下」'
Say ''
Say '  DSH 会分批读、边读边把记忆卡填好 —— 之后它就能接着你以前的事干了。'
Say ''
Read-Host '  按回车关闭'
