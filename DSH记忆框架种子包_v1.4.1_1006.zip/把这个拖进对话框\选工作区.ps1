﻿<#
  选工作区 · 列出这台机器上 DSH 用过的工作区，让用户挑一个装框架
  规则：只找到 1 个 → 不问，直接用；有多个 → 列出来让用户按数字选
  结果写到 -OutFile（给安装器 .bat 读）
#>
param(
    [string]$OutFile
)

$ErrorActionPreference = 'SilentlyContinue'
if (-not $OutFile) { $OutFile = Join-Path $env:TEMP 'dsh_ws_pick.txt' }

# ---- 候选工作区：直接读 DSH 的 workspace.json 全表 ----
#   为什么不解析 .dsh\sessions 的目录名：'-' 既是分隔符又是合法文件名字符，
#   'qwen-agent' 会被还原成 'qwen\agent' —— 那种转义本来就解不回去，别去解。
$wsJson = Join-Path $env:USERPROFILE '.dsh\storages\workspace.json'
$defPath = $null
$cands = New-Object System.Collections.Generic.List[string]

if (Test-Path -LiteralPath $wsJson) {
    $o = $null
    try { $o = Get-Content -Raw -LiteralPath $wsJson -Encoding UTF8 | ConvertFrom-Json } catch { $o = $null }
    if ($o -and $o.tables -and $o.tables.workspaces) {
        $defId = $null
        if ($o.global) { $defId = $o.global.defaultWorkspaceId }
        $others = @()
        foreach ($prop in $o.tables.workspaces.PSObject.Properties) {
            $wp = $prop.Value.path
            if (-not $wp) { continue }
            if ($prop.Name -eq $defId) { $defPath = $wp } else { $others += $wp }
        }
        if ($defPath) { $cands.Add($defPath) }
        foreach ($wp in $others) { $cands.Add($wp) }
    }
}

# 只保留真实存在的路径，顺便去重
$list = @()
foreach ($c in $cands) {
    if ((Test-Path -LiteralPath $c) -and (-not ($list -contains $c))) { $list += $c }
}
# ---- 一个都没有：明说没找到，别假装 ----
if ($list.Count -eq 0) {
    Write-Host ''
    Write-Host '  [工作区] 这台机器上还没发现 DSH 工作区。'
    Write-Host '           先打开一次 DSH 再回来；或把目标文件夹拖到安装器上。'
    Write-Host ''
    exit 2
}

# ---- 只有一个：直接跳过，少烦 ----
if ($list.Count -eq 1) {
    Set-Content -LiteralPath $OutFile -Value $list[0] -Encoding Default
    Write-Host ''
    Write-Host '  [工作区] 只找到这一个工作区，就用它：'
    Write-Host "           $($list[0])"
    Write-Host ''
    exit 0
}

# ---- 多个：让用户选 ----
Write-Host ''
Write-Host '  ================================================'
Write-Host '    框架要搭在哪个工作区里？'
Write-Host '  ================================================'
Write-Host ''
Write-Host '  我发现你这台机器上有这几个 DSH 工作区：'
Write-Host ''
for ($i = 0; $i -lt $list.Count; $i++) {
    $mark = if ($i -eq 0) { '   ← 默认' } else { '' }
    Write-Host ("    {0}) {1}{2}" -f ($i + 1), $list[$i], $mark)
}
Write-Host ''
Write-Host '  选你平时打开 DSH 会进去的那个；不确定就直接回车（用默认）。'
Write-Host ''
$sel = Read-Host '  输入数字再回车'
$idx = 0
if ($sel -match '^\d+$') {
    $n = [int]$sel
    if ($n -ge 1 -and $n -le $list.Count) { $idx = $n - 1 }
}
Set-Content -LiteralPath $OutFile -Value $list[$idx] -Encoding Default
Write-Host ''
Write-Host ("  [工作区] 用这个：" + $list[$idx])
Write-Host ''
exit 0
