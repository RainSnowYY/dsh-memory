﻿<#
  我的工具 · 两件事
    -Action backup  把工作区里的记录打包成一个 zip（放桌面）
    -Action check   只读检查：记录文件有没有被搞坏、.bat 换行符对不对、卡里有没有施工残留
  本脚本不改任何文件（除备份时新建那个 zip）。
#>
param(
    [ValidateSet('backup', 'check')]
    [string]$Action = 'backup'
)

$ErrorActionPreference = 'Stop'
function Say($m) { Write-Host $m }

$ws = $PSScriptRoot
if (-not $ws) { $ws = (Get-Location).Path }
# ⚠️ 本脚本可能装在 框架\ 里：那时候工作区是它的【上一层】，不是它自己
if ((Split-Path $ws -Leaf) -eq '框架') { $ws = Split-Path $ws -Parent }

# =====================================================================
if ($Action -eq 'backup') {
    Say ''
    Say '  ================================================'
    Say '    备份我的记录'
    Say '  ================================================'
    Say ''
    Say "  工作区：$ws"
    Say ''

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $leaf = Split-Path $ws -Leaf
    if (-not $leaf) { $leaf = '我的记忆' }
    $name = $leaf + '_备份_' + $stamp + '.zip'
    $desk = [Environment]::GetFolderPath('Desktop')
    if (-not (Test-Path -LiteralPath $desk)) { $desk = $ws }
    $zip = Join-Path $desk $name

    $tmp = Join-Path $env:TEMP ('membak_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null

    try {
        # 1) 顶层记录文件（⭐ 含 AGENTS.md / AGENTS.md.off —— 自动加载被关掉时也不能漏）
        Get-ChildItem -LiteralPath $ws -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in '.md', '.txt', '.bat', '.js', '.json', '.png', '.off' } |
            ForEach-Object { Copy-Item $_.FullName $tmp -Force }

        # 2) 记录目录（保留结构）
        foreach ($d in @('对话记录', '归档', '备份')) {
            $s = Join-Path $ws $d
            if (Test-Path -LiteralPath $s) {
                Copy-Item -LiteralPath $s -Destination (Join-Path $tmp $d) -Recurse -Force -ErrorAction SilentlyContinue
                Say "  [打包] $d\"
            }
        }

        # 1.5) 框架本体（换电脑时必须有它，否则新机器不知道读哪份"施工图"）
        $fw = Join-Path $ws '框架'
        if (Test-Path -LiteralPath $fw) {
            $fwFiles = Get-ChildItem -LiteralPath $fw -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in '.md', '.ps1', '.bat', '.json', '.png', '.js' -and $_.FullName -notlike '*\导入结果\*' }
            foreach ($x in $fwFiles) {
                $rel = $x.FullName.Substring($ws.Length + 1)
                $dstFile = Join-Path $tmp $rel
                $dstDir = Split-Path $dstFile -Parent
                if (-not (Test-Path -LiteralPath $dstDir)) { New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
                Copy-Item -LiteralPath $x.FullName -Destination $dstFile -Force
            }
            Say ("  [打包] 框架\（{0} 个文件）" -f $fwFiles.Count)
        }

        $n = @(Get-ChildItem -LiteralPath $tmp -Recurse -File -ErrorAction SilentlyContinue).Count
        if ($n -eq 0) { Say '  [失败] 这里没有可打包的记录文件。'; exit 1 }

        Say ''
        Say "  共 $n 个文件，正在压缩 ..."
        $base = $zip -replace '\.zip$',''
        $i = 2
        while (Test-Path -LiteralPath $zip) { $zip = $base + '_' + $i + '.zip'; $i++ }
        Compress-Archive -Path (Join-Path $tmp '*') -DestinationPath $zip -CompressionLevel Optimal

        # 2) 压缩后自检：文件在、大小>0、能解开、关键文件在
        $zi = Get-Item -LiteralPath $zip
        if (-not $zi -or $zi.Length -le 0) {
            Say '  [失败] 备份文件没生成或为空。'
            exit 1
        }
        $verify = Join-Path $env:TEMP ('membak_verify_' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $verify -Force | Out-Null
        try {
            Expand-Archive -LiteralPath $zip -DestinationPath $verify -Force -ErrorAction Stop
            $vn = @(Get-ChildItem -LiteralPath $verify -Recurse -File -ErrorAction SilentlyContinue).Count
            # 固定清单：源里缺了文件也要报出来，不能用"现存文件"当清单（否则缺卡时自检永远通过）
            # ⭐ AGENTS.md 和 AGENTS.md.off 是同一个开关的两面，有其一就算在
            $keys = @('00-核心记忆卡.md')
            $missing = @()
            foreach ($k in $keys) {
                if (-not (Test-Path -LiteralPath (Join-Path $verify $k))) { $missing += $k }
            }
            if (-not (Test-Path -LiteralPath (Join-Path $verify 'AGENTS.md')) -and
                -not (Test-Path -LiteralPath (Join-Path $verify 'AGENTS.md.off'))) {
                $missing += 'AGENTS.md（或 AGENTS.md.off）'
            }
            if ($vn -ne $n -or $missing.Count -gt 0) {
                Say ("  [失败] 备份自检没过：压缩包里 {0} 个文件，应为 {1}；缺：{2}" -f $vn, $n, ($missing -join '、'))
                Say '         这个 zip 先留着，别删；请把这段报给我。'
                exit 1
            }
            Say ("  [自检] 压缩包能打开，{0} 个文件，关键文件都在" -f $vn)
        }
        catch {
            Say ("  [失败] 备份自检打不开这个 zip：{0}" -f $_.Exception.Message)
            Say '         这个 zip 先留着，别删；请把这段报给我。'
            exit 1
        }
        finally {
            if (Test-Path -LiteralPath $verify) { Remove-Item -LiteralPath $verify -Recurse -Force -ErrorAction SilentlyContinue }
        }
        Say ''
        Say '  [完成] 备份好了'
        Say ("         文件：{0}" -f $zi.FullName)
        Say ("         大小：{0:N0} KB" -f ($zi.Length / 1KB))
        Say ''
        Say '  这个 zip 就是你的全部记录 —— 换电脑、重装、存网盘，都靠它。'
    }
    finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
    }
    exit 0
}

# =====================================================================
if ($Action -eq 'check') {
    Say ''
    Say '  ================================================'
    Say '    检查记录有没有坏（只读，不改任何东西）'
    Say '  ================================================'
    Say ''
    Say "  工作区：$ws"
    Say ''

    $problems = 0
    $checked = 0

    $hasPollution = $false
    $hasLf = $false
    $hasEnc = $false
    $hasFence = $false

    # ---- 1. Markdown 文件：转义污染 / 空文件 / 代码块没闭合 ----
    $mds = Get-ChildItem -LiteralPath $ws -File -Filter *.md -ErrorAction SilentlyContinue
    foreach ($f in $mds) {
        $checked++
        $raw = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
        if (-not $raw) { $raw = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue }
        if (-not $raw) { continue }

        $bad = @()
        $hits = @{}
        $inFence = $false
        foreach ($ln in ($raw -split "`r?`n")) {
            if ($ln -match '^\s*```') { $inFence = -not $inFence; continue }
            if ($inFence) { continue }
            $t = $ln -replace '`[^`]*`', ''
            if ($t -match '^\s*\\\*') { $hits['加粗标记前多了反斜杠'] = 1 + ($hits['加粗标记前多了反斜杠']) }
            if ($t -match '\\\\') { $hits['连续反斜杠'] = 1 + ($hits['连续反斜杠']) }
            if ($t -match '(?i)<b>|</b>') { $hits['混进了 HTML 的 b 标签'] = 1 + ($hits['混进了 HTML 的 b 标签']) }
        }
        foreach ($h in $hits.GetEnumerator()) {
            if ($h.Value -ge 2) { $bad += ("{0}（{1} 处）" -f $h.Key, $h.Value) }
        }
        if ($inFence) { $bad += '代码块（```）没有闭合 —— 它后面的内容这次被跳过了，可能漏检' ; $hasFence = $true }
        if ($f.Length -eq 0) { $bad += '文件是 0 字节' }

        if ($bad.Count -gt 0) {
            $problems++
            $hasPollution = $true
            Say ("  [有问题] {0}" -f $f.Name)
            foreach ($b in $bad) { Say ("           · " + $b) }
        }
    }
    Say ("  已检查 {0} 个 .md 文件（只查工作区根目录，归档\、对话记录\ 这些子文件夹里的 .md 不在本次范围内）" -f $checked)

    # ---- 2. .bat 文件：换行符 + 编码（chcp 936 必须配 GBK，否则中文乱码）----
    $bats = Get-ChildItem -LiteralPath $ws -File -Filter *.bat -Recurse -ErrorAction SilentlyContinue
    if ($bats) {
        Say ''
        foreach ($f in $bats) {
            $bytes = [IO.File]::ReadAllBytes($f.FullName)
            $lf = 0
            for ($i = 0; $i -lt $bytes.Length; $i++) {
                if ($bytes[$i] -eq 10 -and -not ($i -gt 0 -and $bytes[$i - 1] -eq 13)) { $lf++ }
            }
            $badBat = @()
            if ($lf -gt 0) { $badBat += ("{0} 处裸 LF 换行（会让它双击闪退）" -f $lf); $hasLf = $true }

            $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
            $hasHigh = $false
            foreach ($b in $bytes) { if ($b -gt 127) { $hasHigh = $true; break } }
            if ($hasBom) {
                $badBat += '编码是 UTF-8 带 BOM —— chcp 936 下中文会乱码'
                $hasEnc = $true
            }
            elseif ($hasHigh) {
                $isUtf8 = $false
                try {
                    $strict = [Text.UTF8Encoding]::new($false, $true)
                    [void]$strict.GetString($bytes)
                    $isUtf8 = $true
                } catch { $isUtf8 = $false }
                if ($isUtf8) {
                    # 合法的 UTF-8 bat 只有一种情况不算错：它自己把控制台切到了 65001
                    $ascii = [Text.Encoding]::ASCII.GetString($bytes)
                    if ($ascii -match 'chcp\s+65001') {
                        # UTF-8 + chcp 65001 = 对的搭配，不报
                    } else {
                        $badBat += '编码看起来是 UTF-8（不是 GBK）—— chcp 936 下中文会乱码'
                        $hasEnc = $true
                    }
                }
            }

            if ($badBat.Count -gt 0) {
                $problems++
                Say ("  [有问题] {0}" -f $f.Name)
                foreach ($b in $badBat) { Say ("           · " + $b) }
            }
        }
        Say ("  已检查 {0} 个 .bat 文件（换行符 + 编码）" -f $bats.Count)
    }

    # ---- 3. ⭐ 收尾校验：卡片有没有更新 / 摘要有没有动 ----
    Say ''
    $hasStale = $false
    $hasFat = $false
    $hasRef = $false
    $card = Join-Path $ws '00-核心记忆卡.md'
    if (Test-Path -LiteralPath $card) {
        $cardItem = Get-Item -LiteralPath $card
        $cardTxt = Get-Content -LiteralPath $card -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
        $m = [regex]::Match($cardTxt, '最后更新[：:]?\s*(\d{4}-\d{2}-\d{2})')
        if ($m.Success) {
            $d = [datetime]::MinValue
            if ([datetime]::TryParse($m.Groups[1].Value, [ref]$d)) {
                $days = [int]((Get-Date).Date - $d.Date).TotalDays
                # ⭐ 几天没开电脑，日期旧是正常的；只有"最近 2 天内动过、卡还没更新"才提醒
                $recentFile = $false
                try {
                    $newest = Get-ChildItem -LiteralPath (Join-Path $ws '对话记录') -File -ErrorAction SilentlyContinue |
                              Sort-Object LastWriteTime -Descending | Select-Object -First 1
                    if ($newest -and ((Get-Date) - $newest.LastWriteTime).TotalHours -lt 48) { $recentFile = $true }
                } catch { }
                if ($days -ge 3) {
                    Say ("  [正常] 卡片『最后更新』是 {0}（{1} 天前）—— 几天没用，日期旧是正常的" -f $d.ToString('yyyy-MM-dd'), $days)
                } elseif ($days -ge 1 -and $recentFile) {
                    $hasStale = $true
                    $problems++
                    Say ("  [提醒] 卡片『最后更新』停在 {0}（{1} 天前），但 对话记录\ 里近两天还有新内容 —— 上次很可能没收尾" -f $d.ToString('yyyy-MM-dd'), $days)
                    Say '         下次开新会话它会读到这个日期，自己补记；想现在就补，跟它说「收尾」。'
                } elseif ($days -ge 1) {
                    Say ("  [正常] 卡片『最后更新』是 {0}（{1} 天前；这段时间没有新对话，不用补）" -f $d.ToString('yyyy-MM-dd'), $days)
                } else {
                    Say ("  [OK] 卡片最后更新：{0}" -f $d.ToString('yyyy-MM-dd'))
                }
            }
        } else {
            $hasStale = $true
            $problems++
            Say '  [提醒] 卡片里没有『最后更新：YYYY-MM-DD』这一行 —— 加上它，才能查出"忘了收尾"'
        }
        $kb = [math]::Round($cardItem.Length / 1KB, 1)
        if ($kb -gt 90) {
            $problems++
            $hasFat = $true
            Say ("  [有问题] 卡片 {0} KB，超过 90 KB —— 先看下一节有没有施工残留" -f $kb)
        } elseif ($kb -gt 75) {
            $hasFat = $true
            Say ("  [提醒] 卡片 {0} KB，超过 75 KB —— 先查施工残留，再按冷热分离挪冷内容" -f $kb)
        } else {
            Say ("  [OK] 卡片大小：{0} KB（目标 75 KB 以内）" -f $kb)
        }
    }

    # ---- 3.5 ⭐ 必检文件：这几样少了，框架就是瘸的 ----
    Say ''
    $mustHave = @(
        '00-核心记忆卡.md',
        'read-sessions.js',
        '导出对话.bat',
        '从这里开始.bat',
        '我的工具.bat',
        '启用自动加载规则.bat',
        '禁用自动加载规则.bat',
        '归档\核心记忆卡-历史归档.md',
        '框架\LICENSE.md',
        '框架\CHANGELOG.md',
        '框架\我的工具.ps1',
        '框架\选工作区.ps1',
        '框架\手册\说话与提问.md',
        '框架\手册\收尾与打扫.md',
        '框架\手册\技术坑.md',
        '框架\手册\默认值与模板.md',
        '框架\模板\00-核心记忆卡模板.md'
    )
    $miss = @()
    foreach ($mh in $mustHave) {
        if (-not (Test-Path -LiteralPath (Join-Path $ws $mh))) { $miss += $mh }
    }
    # ⭐ 自动加载开关：AGENTS.md 和 AGENTS.md.off 有其一就对（关掉自动加载不是"缺文件"）
    if (-not (Test-Path -LiteralPath (Join-Path $ws 'AGENTS.md')) -and
        -not (Test-Path -LiteralPath (Join-Path $ws 'AGENTS.md.off'))) {
        $miss += 'AGENTS.md（或 AGENTS.md.off）'
    }
    if ($miss.Count -gt 0) {
        $hasRef = $true
        $problems += $miss.Count
        foreach ($x in $miss) { Say ("  [缺] " + $x) }
    } else {
        Say '  [OK] 该有的核心文件都在'
    }

    # ---- 3.6 数字自洽：「N 样东西」和它自己列出来的数量对得上吗 ----
    $ug = Join-Path $ws '有问题翻这里.md'
    if (Test-Path -LiteralPath $ug) {
        $ut = Get-Content -LiteralPath $ug -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
        $mm2 = [regex]::Match($ut, '\*\*(\d+)\s*样东西\*\*：(.+)')
        if ($mm2.Success) {
            $claim = [int]$mm2.Groups[1].Value
            $names = [regex]::Matches($mm2.Groups[2].Value, '`([^`]+)`')
            if ($claim -ne $names.Count) {
                $hasRef = $true
                $problems++
                Say ("  [不一致] 用户须知说「{0} 样东西」，实际列了 {1} 个" -f $claim, $names.Count)
            } else {
                Say ("  [OK] 「{0} 样东西」和列出的数量一致" -f $claim)
            }
        } else {
            Say '  [跳过] 这版用户须知里没有「N 样东西」句式 —— 这项不适用（不是没查）'
        }
    }

    # ---- 3.7 ⭐⭐ 施工残留：热卡里绝不能有"施工期"的东西 ----
    Say ''
    $hasLeak = $false
    if (Test-Path -LiteralPath $card) {
        $ct = Get-Content -LiteralPath $card -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
        if ($ct) {
            $leaks = @()
            if ($ct -match '##\s*⚙️?\s*施工区') { $leaks += '还留着「施工区」整节' }
            if ($ct -match '<!--\s*施工\s*-->') { $leaks += '还有 <!--施工--> 行内标记' }
            $ph = ([regex]::Matches($ct, '【待填')).Count
            # 模板本身有 30 处【待填】；照模板建出来的卡，§三/§3.1 本来就留着几处等用户开口。
            # 超过 20 处 ≈ 把模板整份抄过来了（那才是施工残留）。
            if ($ph -gt 20) { $leaks += ("还有 {0} 处【待填】没填 —— 像是把模板整份抄进热卡了（超过 20 处才算问题）" -f $ph) }
            elseif ($ph -gt 0) { Say ("  [正常] 还有 {0} 处【待填】在「用户是谁」那节，边干边填就行" -f $ph) }
            if ($leaks.Count -gt 0) {
                $hasLeak = $true
                $problems += $leaks.Count
                foreach ($lk in $leaks) { Say ("  [有问题] 热卡里" + $lk) }
                Say '         施工区本来就不该进卡（见施工单「钉子①」）。清掉再收尾。'
            } elseif ($ct -notmatch '✅\s*\*{0,2}\s*已初始化：\s*\*{0,2}\s*\d{4}-\d{2}-\d{2}') {
                $hasLeak = $true
                $problems++
                Say '  [提醒] 卡头没有「✅ 已初始化：<日期>」这一行 —— 要么是模板，要么被覆盖过，先确认再动手。'
            } else {
                Say '  [OK] 热卡里没有施工残留，初始化标记也在'
            }
        }
    }

    # ---- 4. 结论：按具体问题给具体修法 ----
    Say ''
    if ($problems -eq 0) {
        Say '  [结论] 没发现问题，记录是健康的 ✔'
        Say ''
        Say '  如果还是觉得哪里不对，就把截图发给你买框架的那个人。'
    }
    else {
        Say ("  [结论] 发现 {0} 处问题。下面按类型给修法 —— 复制对应那句发给我就行：" -f $problems)
        Say ''
        if ($hasPollution) {
            Say '  · 记录文件被污染（多出反斜杠 / HTML 标签 / 空文件 / 代码块没闭合）'
            Say '    跟我说：「我的记录文件转义污染了，按框架第五节 §5.4 修一下」'
            Say ''
        }
        if ($hasLf) {
            Say '  · 有 .bat 的换行坏了（裸 LF，双击会闪退）'
            Say '    跟我说：「把 框架\ 里的 .bat 全部换成 CRLF 换行，编码用 GBK」'
            Say ''
        }
        if ($hasEnc) {
            Say '  · 有 .bat 的编码不对（UTF-8 配 chcp 936 会乱码）'
            Say '    跟我说：「把 框架\ 里的 .bat 重新存成 GBK 编码 + CRLF 换行」'
            Say ''
        }
        if ($hasStale) {
            Say '  · 卡片可能没更新（『最后更新』日期太旧，或根本没有这一行）'
            Say '    跟我说：「按收尾 5 步补一次，把卡头的最后更新改成今天」'
            Say ''
        }
        if ($hasFat) {
            Say '  · 卡片偏大（超过 75 KB 的目标）'
            Say '    跟我说：「按冷热分离把用不上的挪进 归档\；先确认里面没有施工残留」'
            Say ''
        }
        if ($hasLeak) {
            Say '  · 热卡里有施工期残留（施工区 / 【待填】 / 缺 ✅ 已初始化 标记）'
            Say '    跟我说：「按施工单钉子①把热卡里的施工残留清掉」'
            Say ''
        }
        if ($hasRef) {
            Say '  · 文档里说的文件/数量和实际对不上'
            Say '    跟我说：「按检查记录报的清单，把缺的补上、把数字改对」'
            Say ''
        }
        Say '  ⚠️ 动手修之前，先跑一次备份（菜单里选 1），万一改坏还能退回去。'
    }
    Say ''
    exit 0
}
