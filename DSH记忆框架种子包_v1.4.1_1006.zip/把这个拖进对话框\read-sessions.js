#!/usr/bin/env node
/*
 * read-sessions.js —— 把 DSH 的会话记录导出成人人可读的 Markdown
 * ------------------------------------------------------------------
 * 记录位置：%USERPROFILE%\.dsh\sessions\<工作区转义名>\<会话ID>\session.v4.jsonl.zstd
 *   （脚本会递归扫所有 .jsonl.zstd，再按文件里记的 cwd 过滤出「本工作区」的会话；
 *     子代理会话的目录名不是 session- 开头，直接跳过 —— 那些是 AI 内部任务。）
 * 输出位置：本脚本所在文件夹下的「对话记录\」
 * 用法：双击「导出对话.bat」，或  node read-sessions.js
 *
 * 只负责导出，不改记录、不联网。
 * ------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const HOME = process.env.USERPROFILE || process.env.HOME || '';
const SESS_ROOT = path.join(HOME, '.dsh', 'sessions');
const WS = path.resolve(__dirname);
const OUT_DIR = path.join(WS, '对话记录');

let skippedAgentSessions = 0;

function norm(p) {
  return String(p || '').replace(/[\\/]+$/, '').toLowerCase();
}

function findSessionFiles(root) {
  const out = [];
  (function walk(d) {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.name.endsWith('.jsonl.zstd')) {
        // 只导出「用户的会话」：目录名形如 session-<uuid>。
        // 子代理会话的目录名是裸 UUID，是 AI 内部任务，不是你和它的对话。
        if (!/^session-/.test(path.basename(path.dirname(p)))) { skippedAgentSessions++; continue; }
        out.push(p);
      }
    }
  })(root);
  return out;
}

// 会话文件是「多个 zstd 帧首尾相接」拼成的，必须按魔数切帧逐个解压
// ⚠️ 已知局限：这四个字节在压缩数据内部理论上也可能出现 —— 那一帧会解压失败被跳过（少几行，不报错）。
//    实测正常会话文件里每帧边界都是真魔数，没见误命中；真碰上的症状是「某几条对话没导出来」。
function decompress(p) {
  const buf = fs.readFileSync(p);
  const M = [0x28, 0xB5, 0x2F, 0xFD];
  const offs = [];
  for (let i = 0; i + 4 <= buf.length; i++) {
    if (buf[i] === M[0] && buf[i + 1] === M[1] && buf[i + 2] === M[2] && buf[i + 3] === M[3]) offs.push(i);
  }
  if (!offs.length) {
    try { return zlib.zstdDecompressSync(buf).toString('utf8'); } catch { return ''; }
  }
  let s = '';
  for (let k = 0; k < offs.length; k++) {
    const a = offs[k], b = (k + 1 < offs.length) ? offs[k + 1] : buf.length;
    try { s += zlib.zstdDecompressSync(buf.subarray(a, b)).toString('utf8'); } catch { /* 跳过坏帧 */ }
  }
  return s;
}

function ts(ms) {
  if (!ms) return '';
  const d = new Date(ms);
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' +
         p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

function clip(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n) + '\n…（已截断，原文共 ' + s.length + ' 字）' : s;
}

function plainText(content) {
  if (!content) return '';
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content.filter(c => c && c.type === 'text').map(c => c.text || '').join('\n');
  }
  return '';
}

function safeName(s) {
  return String(s || '').replace(/[\\/:*?"<>|\r\n]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 60);
}

// ---------- 把单个会话转成 Markdown（先不落盘，等筛完工作区再写） ----------
function buildSession(file) {
  const raw = decompress(file);
  if (!raw.trim()) return null;

  const events = [];
  for (const line of raw.split('\n')) {
    const t = line.trim();
    if (!t) continue;
    try { events.push(JSON.parse(t)); } catch { /* 忽略解析失败的行 */ }
  }
  if (!events.length) return null;

  const head = events.find(e => e.type === 'session') || {};
  let title = '';
  for (const e of events) {
    if (e.type === 'session/title' && e.data && e.data.title) title = e.data.title;
  }

  const md = [];
  md.push('# 对话记录 · ' + (title || '(无标题)'));
  md.push('');
  md.push('| 项 | 值 |');
  md.push('|---|---|');
  md.push('| 会话 ID | `' + (head.id || path.basename(path.dirname(file))) + '` |');
  md.push('| 工作目录 | `' + (head.cwd || '未知') + '` |');
  md.push('| 创建时间 | ' + ts(head.createdAt) + ' |');
  md.push('| 事件总数 | ' + events.length + ' |');
  md.push('| 源文件 | `' + file + '` |');
  md.push('');
  md.push('---');
  md.push('');

  let turn = 0, userCount = 0, assistantCount = 0, toolCount = 0;

  for (const e of events) {
    const d = e.data || {};
    switch (e.type) {

      case 'turn/start':
        turn = d.turn || turn + 1;
        md.push('');
        md.push('# 第 ' + turn + ' 轮');
        md.push('');
        break;

      case 'user/message': {
        const txt = plainText(d.content);
        if (!txt) break;
        // 跳过运行时注入的伪"用户消息"（上下文快照、技能目录提醒等）
        if (/^Current runtime context\./.test(txt)) break;
        if (/<system-reminder>/.test(txt)) break;
        if (/^<available_skills>/.test(txt.trim())) break;
        userCount++;
        md.push('## 👤 你　`' + ts(e.time) + '`');
        md.push('');
        md.push(txt);
        md.push('');
        break;
      }

      case 'assistant/message': {
        const msg = d.message || {};
        const parts = Array.isArray(msg.content) ? msg.content : [];
        const texts = parts.filter(p => p && p.type === 'text').map(p => p.text || '').join('\n').trim();
        const thinks = parts.filter(p => p && p.type === 'reasoning').map(p => p.text || '').join('\n').trim();
        if (!texts && !thinks) break;
        assistantCount++;
        md.push('## 🤖 助手　`' + ts(e.time) + '`');
        md.push('');
        if (thinks) {
          md.push('<details><summary>🧠 思考过程（点击展开）</summary>');
          md.push('');
          md.push(clip(thinks, 4000));
          md.push('');
          md.push('</details>');
          md.push('');
        }
        if (texts) { md.push(texts); md.push(''); }
        break;
      }

      case 'tool/call': {
        toolCount++;
        let args = d.arguments;
        try { args = JSON.stringify(JSON.parse(args)); } catch { /* 保持原样 */ }
        md.push('- 🔧 **' + d.name + '**　`' + clip(args, 300).replace(/\n/g, ' ') + '`');
        break;
      }

      case 'tool/result': {
        const msg = d.message || {};
        const txt = plainText(msg.content);
        const flag = msg.isError ? '❌' : '📄';
        md.push('  - ' + flag + ' ' + clip(txt, 700).replace(/\n+/g, ' ⏎ '));
        break;
      }

      case 'approval/asked':
        md.push('- ⚠️ **请求授权**：' + clip((d.reason || d.toolName || ''), 300));
        break;

      case 'approval/decided':
        md.push('  - 你的决定：**' + (d.outcome || '') + '**');
        break;

      case 'deliverables/presented': {
        const fs2 = (d.files || []).map(f => '`' + f.path + '`').join('、');
        if (fs2) md.push('- 📦 **交付文件**：' + fs2);
        break;
      }

      default:
        break;
    }
  }

  const id = head.id || path.basename(path.dirname(file));
  const name = safeName((head.createdAt ? ts(head.createdAt).slice(0, 10) : '') + '_' + (title || 'session') + '_' + String(id).slice(-8)) + '.md';

  return {
    md: md.join('\n'),
    name,
    meta: {
      id,
      cwd: head.cwd || '',
      title: title || '(无标题)',
      createdAt: head.createdAt || 0,
      events: events.length,
      users: userCount,
      assistants: assistantCount,
      tools: toolCount,
      size: fs.statSync(file).size
    }
  };
}

function main() {
  if (!fs.existsSync(SESS_ROOT)) {
    console.error('找不到会话目录：' + SESS_ROOT);
    console.error('（这台机器还没打开过 DSH？先打开一次再试。这次不算导出成功。）');
    process.exitCode = 1;   // ⭐ 别让 .bat 把"没找到"当成"成功"
    return;
  }

  // ⚠️ 两个进程同时跑，会往 对话记录\ 里写同一批文件，结果可能互相覆盖。
  //    这里只做「提醒」不硬拦：发现锁文件很新就提示一句，照常往下跑。
  const LOCK = path.join(require('os').tmpdir(), 'dsh-export-' + WS.replace(/[^A-Za-z0-9]+/g, '_').slice(-48) + '.lock');
  try {
    if (fs.existsSync(LOCK) && Date.now() - fs.statSync(LOCK).mtimeMs < 10 * 60 * 1000) {
      console.log('  （检测到另一次导出可能正在跑 —— 同时跑两份，结果可能互相覆盖）\n');
    }
    fs.writeFileSync(LOCK, String(Date.now()));
  } catch { /* 锁只是提醒，写不了就算了 */ }

  const files = findSessionFiles(SESS_ROOT);
  console.log('工作区：' + WS);
  console.log('发现 ' + files.length + ' 个会话文件，开始导出…\n');
  if (skippedAgentSessions > 0) {
    console.log('  （已跳过 ' + skippedAgentSessions + ' 个「子代理内部会话」，它们不是你的对话）\n');
  }

  const built = [];
  let failed = 0;
  for (const f of files) {
    try {
      const r = buildSession(f);
      if (r) built.push(r);
      else console.log('  · 跳过（空会话）：' + path.basename(path.dirname(f)));
    } catch (err) {
      failed++;
      console.log('  ✖ 失败：' + f + ' → ' + err.message);
    }
  }

  // ⭐ 只导出属于「这个工作区」的会话。
  // 一个都对不上时（新装的工作区就是这种），默认什么都不导 ——
  // 不能把本机别的文件夹的聊天灌进这个新工作区（那是别人的东西）。
  // 真要看全部：node read-sessions.js --all
  const wantAll = process.argv.slice(2).includes('--all');
  const mine = built.filter(b => norm(b.meta.cwd) === norm(WS));
  let use = mine;
  if (!mine.length) {
    if (wantAll) {
      use = built;
      console.log('\n  [说明] 没找到属于本工作区的会话；按 --all 把本机 ' + built.length + ' 个都导出来。');
    } else {
      use = [];
      console.log('\n  [说明] 本机没有属于这个工作区的会话 —— 新装的工作区本来就是这样，正常。');
      console.log('         别的文件夹的对话不会导进来（那是另一份记录）。');
      console.log('         真要看本机全部：在命令行里跑  node read-sessions.js --all');
    }
  } else if (mine.length !== built.length) {
    console.log('\n  [说明] 本机共 ' + built.length + ' 个会话，属于这个工作区的 ' + mine.length + ' 个；其余（别的文件夹的）不导。');
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const results = [];
  for (const b of use) {
    fs.writeFileSync(path.join(OUT_DIR, b.name), b.md, 'utf8');
    const r = b.meta;
    results.push(r);
    console.log('  ✔ ' + r.title);
    console.log('      ' + r.events + ' 事件 / 你 ' + r.users + ' 条 / 助手 ' + r.assistants +
                ' 条 / 工具 ' + r.tools + ' 次 / 原文件 ' + (r.size / 1024).toFixed(0) + ' KB');
  }

  results.sort((a, b) => a.createdAt - b.createdAt);
  const idx = ['# 对话记录索引', '', '导出时间：' + ts(Date.now()), '',
    '| 时间 | 标题 | 你 | 助手 | 工具 | 事件 | 工作目录 |', '|---|---|---|---|---|---|---|'];
  for (const r of results) {
    idx.push('| ' + ts(r.createdAt) + ' | ' + r.title + ' | ' + r.users + ' | ' + r.assistants +
             ' | ' + r.tools + ' | ' + r.events + ' | `' + r.cwd + '` |');
  }
  idx.push('');
  idx.push('> 每个会话的完整对话正文在同目录下的各个 `.md` 文件里。');
  fs.writeFileSync(path.join(OUT_DIR, '00-对话记录索引.md'), idx.join('\n'), 'utf8');

  console.log('\n导出完成 → ' + OUT_DIR);
  console.log('共 ' + results.length + ' 个会话。');
  if (failed > 0) {
    console.log('\n⚠️ 有 ' + failed + ' 个会话没导出来（上面标 ✖ 的那几个）。这次只算部分成功。');
    process.exitCode = 1;
  }

  try { fs.unlinkSync(LOCK); } catch { /* 没锁也无所谓 */ }
}

main();
